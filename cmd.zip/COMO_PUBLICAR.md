# Como Publicar o "Moz We On" na Internet Grátis! 🇲🇿🚀

Se não tens dinheiro para pagar alojamento de servidores ou base de dados, não te preocupes! O **Moz We On** foi desenhado especificamente para funcionar de forma **100% estática e offline**, salvando músicas e preferências diretamente no navegador do utilizador através do `localStorage` e Cache API.

Isso significa que podes publicar esta plataforma na internet **totalmente grátis**! Aqui está o guia passo a passo de como fazer isso.

---

## Opção 1: Publicar no Netlify (A mais recomendada e fácil!)
O Netlify é gratuito, super rápido e podes colocar o site online em menos de 2 minutos apenas arrastando a pasta.

1. **Gera os ficheiros estáticos (Build):**
   - No teu terminal local, executa:
     ```bash
     npm run build
     ```
   - Isso vai criar uma pasta chamada `dist` no teu projeto. Essa pasta contém todos os ficheiros prontos para a internet (HTML, JS, CSS, Imagens, etc.).

2. **Cria uma conta no Netlify:**
   - Acede a [netlify.com](https://www.netlify.com/) e cria uma conta grátis.

3. **Arrasta e Solta (Drag and Drop):**
   - Vai para a aba **Sites** no Netlify.
   - Desce até veres a caixa que diz *"Want to deploy a new site without connecting to Git? Drag and drop your site folder here"*.
   - **Arrasta apenas a pasta `dist`** para essa caixa!

4. **Pronto!**
   - O Netlify vai dar-te um link público gratuito (por exemplo: `https://nome-aleatorio.netlify.app`) onde qualquer pessoa em Moçambique e no mundo poderá aceder ao teu site, ouvir as músicas e criar playlists!

---

## Opção 2: Publicar no Vercel (Excelente e gratuito!)
A Vercel também oferece alojamento gratuito para aplicações frontend.

1. **Gera os ficheiros estáticos:**
   - Corre o comando `npm run build` para criar a pasta `dist`.

2. **Publica através do Vercel CLI ou GitHub:**
   - Cria uma conta gratuita em [vercel.com](https://vercel.com).
   - Se usas o GitHub, podes conectar o teu repositório diretamente e a Vercel compila e publica automaticamente a pasta `dist`.

---

## Opção 3: Publicar no GitHub Pages (100% grátis e para sempre!)
Se tens uma conta no GitHub:

1. Cria um repositório público chamado `nome-do-teu-projeto`.
2. Envia os ficheiros para lá.
3. Nas **Settings (Definições)** do repositório, vai a **Pages** e ativa a publicação a partir do branch principal (`main` ou `gh-pages`).

---

## Como testar localmente antes de enviar para a internet?

Se tentares abrir o ficheiro `index.html` diretamente da pasta `dist` dando dois cliques nele no teu computador (usando o protocolo `file://`), a maior parte dos navegadores modernos vai bloquear a inicialização por motivos de segurança (CORS).

Para testar localmente de forma correta e sem erros, deves correr um servidor local:

1. Abre o terminal na pasta do projeto e corre:
   ```bash
   npm run dev
   ```
2. Abre o link que aparece no terminal (normalmente `http://localhost:3000`).

---

## 🎶 O que funciona na versão grátis (estática)?
Tudo o que os teus ouvintes precisam está totalmente funcional mesmo sem servidor:
* **Leitor de Música com Sintetizadores Digitais:** As batidas moçambicanas de Marrabenta, Amapiano, Kizomba, Pandza e Afro House tocam em tempo real através da Web Audio API!
* **Upload de Músicas:** Os utilizadores podem subir os seus ficheiros de áudio `.mp3` ou usar sintetizadores e o site guarda localmente no navegador deles.
* **Playlists:** Criar playlists personalizadas e adicionar faixas.
* **DJ Moz AI (Curador):** O chat inteligente com o DJ Moz responderá de forma calorosa usando termos e gírias moçambicanas diretamente do navegador!
* **Estatísticas de Género e Histórico:** Gráficos interativos em tempo real baseados nos sons mais ouvidos.
