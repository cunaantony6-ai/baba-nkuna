import { Track, Playlist } from "../types";

// Generates wave heights for the visual seekbar
function generateWaveform(count = 40): number[] {
  return Array.from({ length: count }, () => Math.round((0.1 + Math.random() * 0.9) * 100) / 100);
}

export const DEFAULT_TRACKS: Track[] = [
  {
    id: "track-1",
    title: "Keta Moçambique",
    artist: "Mr. Bow",
    genre: "Marrabenta",
    description: "Uma celebração moderna dos ritmos tradicionais de Marrabenta. Sinta a guitarra quente do sul de Moçambique!",
    audioUrl: "synth:marrabenta_guitar",
    coverUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400&auto=format&fit=crop&q=60",
    duration: 180,
    likesCount: 342,
    playCount: 1540,
    uploadedBy: "Sistema",
    createdAt: "2026-07-01T12:00:00Z",
    waveform: generateWaveform(50),
    commentsCount: 3
  },
  {
    id: "track-2",
    title: "Maputo Night Shift",
    artist: "DJ Tarico",
    genre: "Amapiano",
    description: "A autêntica batida do Amapiano com as famosas 'log drums' que agitam todas as noites da capital Maputo.",
    audioUrl: "synth:amapiano_bass",
    coverUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400&auto=format&fit=crop&q=60",
    duration: 210,
    likesCount: 512,
    playCount: 3420,
    uploadedBy: "Sistema",
    createdAt: "2026-07-02T15:30:00Z",
    waveform: generateWaveform(50),
    commentsCount: 2
  },
  {
    id: "track-3",
    title: "Coração de Ouro",
    artist: "Cláudio Ismael",
    genre: "Kizomba",
    description: "Uma Kizomba romântica, suave e com aquela doçura vocal irresistível para dançar agarradinho.",
    audioUrl: "synth:kizomba_lead",
    coverUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&auto=format&fit=crop&q=60",
    duration: 195,
    likesCount: 289,
    playCount: 1245,
    uploadedBy: "Sistema",
    createdAt: "2026-07-03T18:20:00Z",
    waveform: generateWaveform(50),
    commentsCount: 1
  },
  {
    id: "track-4",
    title: "Maza Maza (Gueto Beat)",
    artist: "DJ Maputo",
    genre: "Pandza",
    description: "Pandza puro e acelerado! Ritmo do gueto com muita batida, rimas e energia contagiante de Moçambique.",
    audioUrl: "synth:pandza_drums",
    coverUrl: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=400&auto=format&fit=crop&q=60",
    duration: 165,
    likesCount: 418,
    playCount: 2890,
    uploadedBy: "Sistema",
    createdAt: "2026-07-04T09:15:00Z",
    waveform: generateWaveform(50),
    commentsCount: 2
  },
  {
    id: "track-5",
    title: "Zavala Marimba",
    artist: "Timbila Sound System",
    genre: "Afro House",
    description: "Uma fusão incrível das vibrações tradicionais da Timbila de Zavala com batidas eletrónicas pesadas de Afro House.",
    audioUrl: "synth:afro_marimba",
    coverUrl: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=400&auto=format&fit=crop&q=60",
    duration: 240,
    likesCount: 610,
    playCount: 4560,
    uploadedBy: "Sistema",
    createdAt: "2026-07-05T14:45:00Z",
    waveform: generateWaveform(50),
    commentsCount: 4
  }
];

export const DEFAULT_PLAYLISTS: Playlist[] = [
  {
    id: "play-1",
    name: "Hits do Verão Maputo",
    description: "As músicas mais quentes das noites de Moçambique. Sente a energia!",
    coverUrl: "https://images.unsplash.com/photo-1482440308425-276ad0f28b19?w=400&auto=format&fit=crop&q=60",
    trackIds: ["track-1", "track-2", "track-4"],
    createdBy: "DJ Moz",
    createdAt: "2026-07-04T12:00:00Z"
  },
  {
    id: "play-2",
    name: "Marrabenta e Tradição",
    description: "Sons tradicionais e novas fusões da nossa amada Marrabenta e ritmos folclóricos.",
    coverUrl: "https://images.unsplash.com/photo-1511192336575-5a79af67a629?w=400&auto=format&fit=crop&q=60",
    trackIds: ["track-1", "track-3"],
    createdBy: "DJ Moz",
    createdAt: "2026-07-05T10:00:00Z"
  }
];
